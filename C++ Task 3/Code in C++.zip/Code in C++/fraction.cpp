#include "fraction.h"

namespace cs10b_fraction {

    // Default constructor
    Fraction::Fraction() : numerator(0), denominator(1) {}

    // Constructors
    Fraction::Fraction(int num, int denom) : numerator(num), denominator(denom) {
        if (denominator == 0) {
            denominator = 1;
        }
        simplify();
    }

    Fraction::Fraction(int wholeNumber) : numerator(wholeNumber), denominator(1) {}

    // Operator overloads for integer and Fraction operations
    Fraction operator + (int num, const Fraction& frac) {
        return Fraction(num) + frac;
    }

    Fraction operator -(int num, const Fraction& frac) {
        return Fraction(num) - frac;
    }

    Fraction operator *(int num, const Fraction& frac) {
        return Fraction(num) * frac;
    }

    Fraction operator /(int num, const Fraction& frac) {
        return Fraction(num) / frac;
    }


    // Overloaded operators
    std::ostream& operator<<(std::ostream& out, const Fraction& fraction) {
        if (fraction.denominator == 1) {
            out << fraction.numerator;
        } else if (fraction.numerator < fraction.denominator) {
            out << fraction.numerator << '/' << fraction.denominator;
        } else {
            int wholePart = fraction.numerator / fraction.denominator;
            int remainder = fraction.numerator % fraction.denominator;
            out << wholePart << '+' << remainder << '/' << fraction.denominator;
        }
        return out;
    }

    bool operator<(const Fraction& left, const Fraction& right) {
        return (left.numerator * right.denominator) < (right.numerator * left.denominator);
    }

    bool operator<=(const Fraction& left, const Fraction& right) {
        return (left.numerator * right.denominator) <= (right.numerator * left.denominator);
    }

    bool operator>(const Fraction& left, const Fraction& right) {
        return (left.numerator * right.denominator) > (right.numerator * left.denominator);
    }

    bool operator>=(const Fraction& left, const Fraction& right) {
        return (left.numerator * right.denominator) >= (right.numerator * left.denominator);
    }

    bool operator==(const Fraction& left, const Fraction& right) {
        return (left.numerator * right.denominator) == (right.numerator * left.denominator);
    }

    bool operator!=(const Fraction& left, const Fraction& right) {
        return (left.numerator * right.denominator) != (right.numerator * left.denominator);
    }

    // Arithmetic operators
    Fraction Fraction::operator+(const Fraction& other) const {
        Fraction result(numerator * other.denominator + other.numerator * denominator,
                        denominator * other.denominator);
        result.simplify();
        return result;
    }

    Fraction Fraction::operator-(const Fraction& other) const {
        Fraction result(numerator * other.denominator - other.numerator * denominator,
                        denominator * other.denominator);
        result.simplify();
        return result;
    }

    Fraction Fraction::operator*(const Fraction& other) const {
        Fraction result(numerator * other.numerator, denominator * other.denominator);
        result.simplify();
        return result;
    }

    Fraction Fraction::operator/(const Fraction& other) const {
        Fraction result(numerator * other.denominator, denominator * other.numerator);
        result.simplify();
        return result;
    }

    Fraction& Fraction::operator+=(const Fraction& other) {
        *this = *this + other;
        return *this;
    }

    Fraction& Fraction::operator-=(const Fraction& other) {
        *this = *this - other;
        return *this;
    }

    Fraction& Fraction::operator*=(const Fraction& other) {
        *this = *this * other;
        return *this;
    }

    Fraction& Fraction::operator/=(const Fraction& other) {
        *this = *this / other;
        return *this;
    }

    Fraction& Fraction::operator++() {
        *this += 1;
        return *this;
    }

    Fraction Fraction::operator++(int) {
        Fraction temp(*this);
        *this += 1;
        return temp;
    }

    Fraction& Fraction::operator--() {
        *this -= 1;
        return *this;
    }

    Fraction Fraction::operator--(int) {
        Fraction temp(*this);
        *this -= 1;
        return temp;
    }

    std::istream& operator>>(std::istream& in, Fraction& fraction) {
        char slash;
        in >> fraction.numerator;
        in >> slash; // Read the slash character
        if (slash == '/') {
            in >> fraction.denominator;
        } else {
            fraction.denominator = 1; // Default denominator is 1 for whole numbers
        }
        fraction.simplify(); // Simplify the fraction after reading
        return in;
    }

    // Private function to simplify the fraction
    void Fraction::simplify() {
        if (denominator < 0) {
            // Ensure denominator is positive
            numerator *= -1;
            denominator *= -1;
        }
        int gcd = 1;
        int smaller = (numerator < denominator) ? numerator : denominator;
        for (int i = 2; i <= smaller; ++i) {
            if (numerator % i == 0 && denominator % i == 0) {
                gcd = i;
            }
        }
        if (gcd > 1) {
            numerator /= gcd;
            denominator /= gcd;
        }
    }

  

} // namespace cs10b_fraction
